﻿@echo off
chcp 65001 >nul
title Custom Intro - сборка мода
cd /d "%~dp0"

echo ==========================================
echo       CUSTOM INTRO - Forge 1.20.1
echo ==========================================
echo.

where java >nul 2>nul
if errorlevel 1 (
  echo ОШИБКА: Java не найдена.
  echo Установи Java JDK 17 и запусти build.bat снова.
  pause
  exit /b 1
)

echo Проверяю Java...
java -version
echo.

set "GRADLE_DIR=%~dp0.gradle-local"
set "GRADLE_HOME_LOCAL=%GRADLE_DIR%\gradle-8.8"
set "GRADLE_ZIP=%GRADLE_DIR%\gradle-8.8-bin.zip"

if not exist "%GRADLE_HOME_LOCAL%\bin\gradle.bat" (
  echo Скачиваю Gradle 8.8. Нужен интернет...
  if not exist "%GRADLE_DIR%" mkdir "%GRADLE_DIR%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.8-bin.zip' -OutFile '%GRADLE_ZIP%'"
  if errorlevel 1 (
    echo Не удалось скачать Gradle. Проверь интернет и попробуй снова.
    pause
    exit /b 1
  )
  echo Распаковываю Gradle...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%GRADLE_ZIP%' -DestinationPath '%GRADLE_DIR%' -Force"
  if errorlevel 1 (
    echo Не удалось распаковать Gradle.
    pause
    exit /b 1
  )
)

echo.
echo Собираю мод. Первый запуск может занять несколько минут...
call "%GRADLE_HOME_LOCAL%\bin\gradle.bat" --no-daemon build
if errorlevel 1 (
  echo.
  echo СБОРКА НЕ УДАЛАСЬ. Сфотографируй последние строки ошибки и пришли мне.
  pause
  exit /b 1
)

echo.
echo ==========================================
echo ГОТОВО! Ищи файл в build\libs
echo Скопируй customintro-1.0.1.jar в .minecraft\mods
echo Нужны Minecraft 1.20.1, Forge 47.x и Java 17.
echo ==========================================
pause
