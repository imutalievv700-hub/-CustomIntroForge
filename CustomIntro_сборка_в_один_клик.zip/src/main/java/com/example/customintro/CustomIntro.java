package com.example.customintro;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.loading.FMLEnvironment;
import net.minecraftforge.common.MinecraftForge;

@Mod(CustomIntro.MODID)
public class CustomIntro {
    public static final String MODID = "customintro";

    public CustomIntro() {
        if (FMLEnvironment.dist == Dist.CLIENT) {
            MinecraftForge.EVENT_BUS.register(new IntroEvents());
        }
    }
}
