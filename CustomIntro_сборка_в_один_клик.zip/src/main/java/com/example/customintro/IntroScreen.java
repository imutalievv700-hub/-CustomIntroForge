package com.example.customintro;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.io.InputStream;
import java.util.concurrent.atomic.AtomicBoolean;

@OnlyIn(Dist.CLIENT)
public final class IntroScreen extends Screen {
    private static final int FPS = 15;
    private static final int FRAME_COUNT = 801; // 53.4 seconds at 15 fps
    private static final ResourceLocation TEXTURE = new ResourceLocation("customintro", "intro_frame");

    private final long startedAt = System.nanoTime();
    private final AtomicBoolean stopped = new AtomicBoolean(false);
    private DynamicTexture dynamicTexture;
    private Clip audioClip;
    private int displayedFrame = -1;
    private boolean audioStarted = false;

    public IntroScreen() {
        super(Component.literal("Custom Intro"));
    }

    @Override
    protected void init() {
        startAudio();
    }

    private void startAudio() {
        Thread audioThread = new Thread(() -> {
            try (InputStream stream = IntroScreen.class.getResourceAsStream(
                    "/assets/customintro/intro.wav")) {
                if (stream == null || stopped.get()) return;
                try (AudioInputStream audio = AudioSystem.getAudioInputStream(stream)) {
                    Clip clip = AudioSystem.getClip();
                    clip.open(audio);
                    if (stopped.get()) {
                        clip.close();
                        return;
                    }
                    audioClip = clip;
                    audioStarted = true;
                    clip.start();
                }
            } catch (Exception ex) {
                System.err.println("[CustomIntro] Could not play intro audio: " + ex.getMessage());
            }
        }, "CustomIntro-Audio");
        audioThread.setDaemon(true);
        audioThread.start();
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        long elapsed = System.nanoTime() - startedAt;
        int frame = (int) (elapsed / 1_000_000_000L * FPS);

        if (frame >= FRAME_COUNT) {
            finishIntro();
            return;
        }

        if (frame != displayedFrame && frame >= 0) {
            loadFrame(frame, graphics);
            displayedFrame = frame;
        }

        if (dynamicTexture == null) {
            graphics.fill(0, 0, width, height, 0xFF000000);
        } else {
            RenderSystem.setShaderTexture(0, TEXTURE);
            graphics.blit(TEXTURE, 0, 0, 0, 0, width, height, width, height);
        }
    }

    private void loadFrame(int frame, GuiGraphics graphics) {
        String path = String.format("/assets/customintro/frames/frame_%04d.jpg", frame + 1);
        try (InputStream input = IntroScreen.class.getResourceAsStream(path)) {
            if (input == null) return;
            var image = com.mojang.blaze3d.platform.NativeImage.read(input);
            if (dynamicTexture == null) {
                dynamicTexture = new DynamicTexture(image);
                Minecraft.getInstance().getTextureManager().register(TEXTURE, dynamicTexture);
            } else {
                dynamicTexture.close();
                dynamicTexture = new DynamicTexture(image);
                Minecraft.getInstance().getTextureManager().register(TEXTURE, dynamicTexture);
            }
            dynamicTexture.upload();
        } catch (Exception ex) {
            System.err.println("[CustomIntro] Could not load frame " + frame + ": " + ex.getMessage());
        }
    }

    private void finishIntro() {
        stopPlayback();
        Minecraft.getInstance().setScreen(new TitleScreen());
    }

    private void stopPlayback() {
        if (!stopped.compareAndSet(false, true)) return;
        Clip clip = audioClip;
        if (clip != null) {
            clip.stop();
            clip.close();
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) {
            finishIntro();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public void removed() {
        stopPlayback();
        if (dynamicTexture != null) {
            dynamicTexture.close();
            dynamicTexture = null;
        }
        super.removed();
    }
}
