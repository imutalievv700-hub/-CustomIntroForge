package com.example.customintro;

import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public final class IntroEvents {
    private static boolean playedThisLaunch = false;

    @SubscribeEvent
    public void onScreenOpening(ScreenEvent.Opening event) {
        if (!playedThisLaunch && event.getNewScreen() instanceof TitleScreen) {
            playedThisLaunch = true;
            event.setNewScreen(new IntroScreen());
        }
    }
}
